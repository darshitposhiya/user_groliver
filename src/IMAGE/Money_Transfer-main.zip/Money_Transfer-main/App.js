import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AppContainer from './src/navigators';
import { StatusBar } from 'react-native';
import { Provider } from 'react-redux';
import { store } from './src/store/store';
import persistStore from 'redux-persist/es/persistStore';
import { PersistGate } from 'redux-persist/integration/react';

const App = () => {

  let persistor = persistStore(store);
  return (
    <>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor} >
          <NavigationContainer>
            <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent={true} />
            <AppContainer />
          </NavigationContainer>
        </PersistGate>
      </Provider>
    </>
  );
};


export default App;
