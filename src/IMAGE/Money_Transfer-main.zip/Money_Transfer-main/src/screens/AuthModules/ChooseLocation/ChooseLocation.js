import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, Image, } from 'react-native';
import HeaderComp from '../../../components/HeaderComp';
import { images } from '../../../assets/images';
import { screenHeight, vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { fonts } from '../../../assets/fonts/Fonts';
import { colors } from '../../../assets/colors/Colors';
import InputComp from '../../../components/InputComp';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import BtnComp from '../../../components/BtnComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import { useNavigation } from '@react-navigation/native';
import { AppStack } from '../../../navigators/NavActions';
import { Formik } from 'formik';
import { chooseYourLocationValidate } from '../../../utility/Validations';

const ChooseLocation = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const chooseYourLocationHandler = (data) => {
        console.log("chooseLocation", data)
        navigation.dispatch(AppStack)
    }

    return (
        <View style={styles.container}>
            <Formik
                initialValues={chooseYourLocationValidate.initialState}
                validationSchema={chooseYourLocationValidate.schema}
                onSubmit={(values) => chooseYourLocationHandler(values)}
            // innerRef={formRef}
            >
                {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                    <>
                        <KeyboardAwareScrollView>
                            <View style={{ width: '95%', alignSelf: 'center' }}>

                                <Image source={images.location_img}
                                    style={{
                                        height: screenHeight * 0.25,
                                        width: '100%',
                                        resizeMode: 'stretch',
                                        marginTop: vs(20)
                                    }} />

                                <Text style={{ marginTop: vs(20), color: colors.Black, fontSize: fs(24), fontWeight: '700', fontFamily: fonts.bold, }}>Choose your location</Text>

                                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between', alignItems: 'center', marginTop: vs(20) }}>
                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'Country'}
                                            value={values.country}
                                            onChangeText={handleChange("country")}
                                            onBlur={() => setFieldTouched('country')}
                                            touched={touched.country}
                                            errors={errors.country}
                                            input_view={{ borderColor: touched.country && errors.country ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'State'}
                                            value={values.state}
                                            onChangeText={handleChange("state")}
                                            onBlur={() => setFieldTouched('state')}
                                            touched={touched.state}
                                            errors={errors.state}
                                            input_view={{ borderColor: touched.state && errors.state ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between', alignItems: 'center', marginTop: vs(15) }}>
                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'City'}
                                            value={values.city}
                                            onChangeText={handleChange("city")}
                                            onBlur={() => setFieldTouched('city')}
                                            touched={touched.city}
                                            errors={errors.city}
                                            input_view={{ borderColor: touched.city && errors.city ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <TextInputWithLabel
                                            placeholder={'Postal code'}
                                            value={values.postal_code}
                                            onChangeText={handleChange("postal_code")}
                                            onBlur={() => setFieldTouched('postal_code')}
                                            touched={touched.postal_code}
                                            errors={errors.postal_code}
                                            inputStyle={{ borderColor: touched.postal_code && errors.postal_code ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder='Address'
                                    value={values.address}
                                    onChangeText={handleChange("address")}
                                    onBlur={() => setFieldTouched('address')}
                                    touched={touched.address}
                                    errors={errors.address}
                                    multiline={true}
                                    inputStyle={{
                                        height: vs(100), marginTop: vs(15), justifyContent: 'flex-start',
                                        borderColor: touched.address && errors.address ? 'red' : colors.InputGray_Border,
                                    }} />

                                <BtnComp title="Done" onPress={handleSubmit}
                                    btnStyle={{ marginBottom: vs(10), marginTop: vs(40) }} />
                            </View>
                        </KeyboardAwareScrollView>
                    </>
                )}
            </Formik>
        </View >

    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
});

export default ChooseLocation;
