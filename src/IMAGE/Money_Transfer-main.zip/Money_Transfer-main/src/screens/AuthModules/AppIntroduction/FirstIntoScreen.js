import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { images } from '../../../assets/images';
import styles from './Styles';
import { vs } from '../../../utility/ResponsiveStyle';


const FirstIntroScreen = ({ onPress }) => {
    return (
        <View style={styles.container}>
            <Image source={images.intro1}
                style={styles.introScreenImg} />

            <View style={styles.bottom_view}>
                <Text style={styles.into_title}>
                    Easy,Fast & Trusted
                </Text>

                <Text style={[styles.lorem_text, { marginTop: vs(10) }]}>
                    Lorem Ipsum is simply dummy text of the printing
                </Text>
                <Text style={styles.lorem_text}>
                    and typesetting industry.
                </Text>
            </View>

           

        </View>
    );
};


export default FirstIntroScreen;
