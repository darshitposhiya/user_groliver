import { StyleSheet } from 'react-native';
import { moderateScale, moderateVerticalScale, scale, verticalScale } from 'react-native-size-matters';
import { colors } from '../../../assets/colors/Colors';
import { fs, screenHeight, screenWidth, vs } from '../../../utility/ResponsiveStyle';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
    introScreenImg: {
        width: "100%",
        height: screenHeight * 0.60,
        resizeMode: 'stretch'
    },
    bottom_view: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: vs(40)
    },
    into_title: {
        color: colors.Black,
        fontWeight: '600',
        fontSize: fs(22),
        textAlign:'center',
        alignSelf:'center'
    },
    lorem_text: {
        color: colors.Black,
        fontSize: fs(14),
        textAlign:'center',
    },
    Appintro_BottomView: {
        width: '95%',
        alignSelf: 'center',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    Inline_dots: {
        position: 'absolute',
        bottom: vs(22),
        flexDirection: 'row',
    }

})

export default styles;