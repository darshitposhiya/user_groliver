import React, { useState, useLayoutEffect } from 'react';
import { View, Text, StyleSheet, Image, Modal } from 'react-native';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';
import BtnComp from '../../../components/BtnComp';
import { fonts } from '../../../assets/fonts/Fonts';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import { Formik } from 'formik';
import { resetPasswordValidate } from '../../../utility/Validations';

const ResetPassword = () => {

    const navigation = useNavigation()
    const [isVisible1, setVisible1] = useState(true);
    const [isVisible2, setVisible2] = useState(true);
    const [modalVisible, setModalVisible] = useState(false);

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const resetPasswordHandler = (data) => {

        navigation.navigate('SignIn')

    }

    return (
        <View style={styles.container}>
            <KeyboardAwareScrollView>
                <View style={{ width: '95%', alignSelf: 'center' }}>

                    <Text style={{ marginTop: vs(15), fontFamily: fonts.bold, fontSize: fs(24), fontWeight: 'bold', color: colors.Black }}>Change Password</Text>

                    <Text style={{ marginTop: vs(5), fontFamily: fonts.regular, fontSize: fs(16), color: colors.GreyText }}>Set your new password</Text>

                    <Formik
                        initialValues={resetPasswordValidate.initialState}
                        validationSchema={resetPasswordValidate.schema}
                        onSubmit={(values) => resetPasswordHandler(values)}
                    >
                        {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                            <>
                                <TextInputWithLabel
                                    placeholder={'Password'}
                                    value={values.password}
                                    onChangeText={handleChange("password")}
                                    onBlur={() => setFieldTouched('password')}
                                    touched={touched.password}
                                    secureTextEntry={isVisible1}
                                    inputStyle={{ marginTop: vs(20), borderColor: touched.password && errors.password ? 'red' : colors.InputGray_Border }}
                                    icon={isVisible1 ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible1(!isVisible1)}
                                />

                                <TextInputWithLabel
                                    placeholder={'Confirm Password'}
                                    onChangeText={handleChange("confirmPassword")}
                                    onBlur={() => setFieldTouched('confirmPassword')}
                                    touched={touched.confirmPassword}
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.confirmPassword && errors.confirmPassword ? 'red' : colors.InputGray_Border }}
                                    secureTextEntry={isVisible2}
                                    icon={isVisible2 ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible2(!isVisible2)}
                                />

                                <BtnComp title="Change" onPress={handleSubmit} btnStyle={{ marginTop: vs(25) }} />
                            </>
                        )}
                    </Formik>
                </View>
            </KeyboardAwareScrollView>

            <View style={styles.centeredView}>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={modalVisible}
                >
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <Image source={images.success}
                                style={{
                                    height: vs(60),
                                    width: hs(60),
                                    resizeMode: 'contain'
                                }} />
                            <Text style={{
                                fontFamily: fonts.bold,
                                fontSize: fs(24),
                                fontWeight: '700',
                                color: colors.Black,
                                marginTop: vs(20)
                            }}>Password changed!</Text>
                        </View>
                    </View>
                </Modal>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        width: '100%',
    },
    modalView: {
        width: '100%',
        backgroundColor: colors.white,
        padding: hs(40),
        borderRadius: hs(10),
        alignItems: 'center',
        justifyContent: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
});
export default ResetPassword;
