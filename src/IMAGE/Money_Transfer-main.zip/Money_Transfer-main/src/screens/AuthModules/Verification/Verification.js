import React, { useRef, useState, useLayoutEffect } from 'react';
import { View, Text, StyleSheet, TextInput, Pressable } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { fonts } from '../../../assets/fonts/Fonts';
import HeaderComp from '../../../components/HeaderComp';
import BtnComp from '../../../components/BtnComp';
import { useNavigation } from '@react-navigation/native';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';

const Verification = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);


    const pin1Ref = useRef(null);
    const pin2Ref = useRef(null);
    const pin3Ref = useRef(null);
    const pin4Ref = useRef(null);

    const [pin1, setPin1] = useState('');
    const [pin2, setPin2] = useState('');
    const [pin3, setPin3] = useState('');
    const [pin4, setPin4] = useState('');

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>

                <Text style={{ fontFamily: fonts.bold, fontSize: fs(24), fontWeight: '700', color: colors.Black, marginTop: vs(15) }}>Verification Code</Text>

                <Text style={{ marginTop: vs(5), fontFamily: fonts.regular, fontWeight: '400', fontSize: fs(16), color: colors.GreyText }}> We have send the verification code to your email <Text style={{ fontSize: fs(18), color: colors.Black }}>hdjf@hdkdm.com</Text></Text>

                <View style={styles.otp_view}>
                    <View style={[styles.otp_box, { borderColor: pin1 ? colors.Lightblue : colors.InputGray_text }]}>
                        <TextInput style={styles.otptext} selectionColor={colors.Lightblue} inputMode='numeric' maxLength={1} ref={pin1Ref}
                            onChange={(pin1) => {
                                setPin1(pin1)
                                if (pin1 !== null) {
                                    pin2Ref.current.focus()
                                }
                            }} />
                    </View>
                    <View style={[styles.otp_box, { borderColor: pin2 ? colors.Lightblue : colors.InputGray_text }]}>
                        <TextInput style={styles.otptext} selectionColor={colors.Lightblue} inputMode='numeric' maxLength={1} ref={pin2Ref}
                            onChange={(pin2) => {
                                setPin2(pin2)
                                if (pin2 !== null) {
                                    pin3Ref.current.focus()
                                }
                            }} />
                    </View>
                    <View style={[styles.otp_box, { borderColor: pin3 ? colors.Lightblue : colors.InputGray_text }]}>
                        <TextInput style={styles.otptext} selectionColor={colors.Lightblue} inputMode='numeric' maxLength={1} ref={pin3Ref}
                            onChange={(pin3) => {
                                setPin3(pin3)
                                if (pin3 !== null) {
                                    pin4Ref.current.focus()
                                }
                            }} />
                    </View>
                    <View style={[styles.otp_box, { borderColor: pin4 ? colors.Lightblue : colors.InputGray_text }]}>
                        <TextInput style={styles.otptext} selectionColor={colors.Lightblue} inputMode='numeric' maxLength={1} ref={pin4Ref}
                            onChange={(pin4) => { setPin4(pin4) }} />
                    </View>
                </View>

                <BtnComp title="Submit" onPress={() => navigation.navigate('ResetPassword')} btnStyle={{ marginTop: vs(25) }} />

                <View style={{ marginTop: vs(20), alignSelf: 'center', flexDirection: 'row' }}>
                    <Text style={{ fontSize: fs(18), color: colors.GreyText }}>Don't receive code?</Text>
                    <Pressable>
                        <Text style={{
                            color: colors.PrimaryBlue,
                            textDecorationLine: 'underline',
                            fontWeight: '600',
                            fontSize: fs(18)
                        }}> Resend
                        </Text>
                    </Pressable>
                </View>

            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
    otp_view: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        marginTop: vs(25),
        alignItems: 'center',
        width: '90%',
        alignSelf: 'center'
    },
    otp_box: {
        height: vs(55),
        width: hs(55),
        borderWidth: 1,
        backgroundColor: colors.InputGray_text,
        borderRadius: fs(12),
        marginHorizontal: hs(20),
    },
    otptext: {
        fontSize: fs(18),
        color: colors.Black,
        textAlign: 'center',
        fontWeight: '600',
    },
});

export default Verification;
