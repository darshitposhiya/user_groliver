import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import BtnComp from '../../../components/BtnComp';
import { fonts } from '../../../assets/fonts/Fonts';
import { colors } from '../../../assets/colors/Colors';
import { fs, vs, hs } from '../../../utility/ResponsiveStyle';
import { Formik } from 'formik';
import { forgotPasswordValidate } from '../../../utility/Validations';

const ForgotPassword = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const forgotPasswordHandler = (data) => {

        console.log(data, "forgotp_w")
        navigation.navigate('Verification')
    }

    return (
        <View style={styles.container}>

            <View style={{ width: '95%', alignSelf: 'center', }}>

                <Text style={{
                    fontFamily: fonts.bold,
                    fontSize: fs(24),
                    fontWeight: 'bold',
                    color: colors.Black,
                    marginTop: vs(15)
                }}>
                    Forgot Password?
                </Text>

                <Text style={{
                    marginTop: vs(5),
                    fontFamily: fonts.regular,
                    fontSize: fs(16),
                    color: colors.GreyText
                }}>
                    Lorem ipsum is simply dummy text of the printing and  typesetting industry.
                </Text>

                <Formik
                    initialValues={forgotPasswordValidate.initialState}
                    validationSchema={forgotPasswordValidate.schema}
                    onSubmit={(values) => forgotPasswordHandler(values)}
                >
                    {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                        <>
                            <TextInputWithLabel
                                placeholder={'Email'}
                                value={values.email}
                                onChangeText={handleChange("email")}
                                onBlur={() => setFieldTouched('email')}
                                touched={touched.email}
                                keyboardType='email-address'
                                autoCapitalize='none'
                                inputStyle={{ marginTop: vs(25), borderColor: touched.email && errors.email ? 'red' : colors.InputGray_Border }} />

                            <BtnComp title="send OTP"
                                onPress={handleSubmit}
                                btnStyle={{ marginTop: vs(25) }} />
                        </>
                    )}
                </Formik>
            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default ForgotPassword;
