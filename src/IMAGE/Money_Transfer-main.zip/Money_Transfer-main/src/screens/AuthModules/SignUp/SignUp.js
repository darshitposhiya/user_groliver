import React, { useState, useLayoutEffect, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Image, } from 'react-native'
import HeaderComp from '../../../components/HeaderComp';
import { images } from '../../../assets/images';
import { fs, screenHeight, screenWidth, vs, hs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { fonts } from '../../../assets/fonts/Fonts';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import BtnComp from '../../../components/BtnComp';
import { useNavigation } from '@react-navigation/native';
import InputComp from '../../../components/InputComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import { Formik } from "formik";
import { registerValidate } from '../../../utility/Validations';
import { useDispatch } from "react-redux";
import { SignupApi } from '../../../featurers/authSlice';
import { fcmToken } from '../../../utility/Globals';
import AsyncStorage from '@react-native-async-storage/async-storage';


const SignUp = ({ route }) => {

    const formRef = useRef();
    const navigation = useNavigation();
    const [isVisible, setVisible] = useState(true);
    const dispatch = useDispatch();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    useEffect(() => {
        if (formRef.current) {
            formRef.current?.setFieldValue('phone_code', route.params?.countryCode || '');
        }
    }, [formRef, route.params]);

    const signupHandler = async (values) => {

        let formData = new FormData();
        formData.append('first_name', values.first_name);
        formData.append('last_name', values.last_name);
        formData.append('phone_code', route?.params?.phone_code);
        formData.append('phone', values.phone);
        formData.append('password', values.password);
        formData.append('email', values.email);

        const result = await dispatch(SignupApi({ data: formData })).unwrap();
        const token = AsyncStorage.setItem("token", result.data?.api_token)

        if (result?.status == "Success") {
            navigation.navigate("ChooseLocation")
        }
    };

    const selectCountryHandler = () => {
        navigation.navigate('Country', {
            fromSignup: true
        });
    };

    return (

        <View style={styles.container}>
            <KeyboardAwareScrollView>
                <View style={{ width: '95%', alignSelf: 'center' }}>

                    <Image source={images.applogo_login}
                        style={{
                            height: screenHeight * 0.20,
                            width: screenWidth * 0.55,
                            alignSelf: 'center',
                            resizeMode: 'center'
                        }} />

                    <Text style={{ marginTop: vs(15), color: colors.Black, fontSize: fs(24), fontWeight: '700', fontFamily: fonts.bold, }}>Sign Up</Text>

                    <Formik
                        initialValues={registerValidate.initialState}
                        validationSchema={registerValidate.schema}
                        onSubmit={(values) => signupHandler(values)}
                        innerRef={formRef}
                    >
                        {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                            <>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: vs(20), width: '100%' }}>
                                    <View style={{ width: '49%', }}>
                                        <TextInputWithLabel
                                            placeholder={'First name'}
                                            value={values.first_name}
                                            onChangeText={handleChange("first_name")}
                                            onBlur={() => setFieldTouched('first_name')}
                                            touched={touched.first_name}
                                            errors={errors.first_name}
                                            inputStyle={{ borderColor: touched.first_name && errors.first_name ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '49%', }}>
                                        <TextInputWithLabel
                                            placeholder={'Last name'}
                                            value={values.last_name}
                                            onChangeText={handleChange("last_name")}
                                            onBlur={() => setFieldTouched('last_name')}
                                            touched={touched.last_name}
                                            errors={errors.last_name}
                                            inputStyle={{ borderColor: touched.last_name && errors.last_name ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder={'Email'}
                                    value={values.email}
                                    onChangeText={handleChange("email")}
                                    onBlur={() => setFieldTouched('email')}
                                    touched={touched.email}
                                    errors={errors.email}
                                    keyboardType='email-address'
                                    autoCapitalize='none'
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.email && errors.email ? 'red' : colors.InputGray_Border, }} />

                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: vs(15), width: '100%' }}>
                                    <View style={{ width: '25%' }}>
                                        <InputComp
                                            placeholder={'+27'}
                                            value={values.phone_code}
                                            onChangeText={handleChange("phone_code")}
                                            onBlur={() => setFieldTouched('phone_code')}
                                            touched={touched.phone_code}
                                            errors={errors.phone_code}
                                            editable={false}
                                            pointerEvents="box-only"
                                            onPress={selectCountryHandler}
                                            input_view={{ borderColor: touched.phone_code && errors.phone_code ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '73%' }}>
                                        <TextInputWithLabel
                                            placeholder={'Phone number'}
                                            value={values.phone}
                                            onChangeText={handleChange("phone")}
                                            onBlur={() => setFieldTouched('phone')}
                                            touched={touched.phone}
                                            errors={errors.phone}
                                            keyboardType='numeric'
                                            inputStyle={{ borderColor: touched.phone && errors.phone ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder={'Password'}
                                    value={values.password}
                                    onChangeText={handleChange("password")}
                                    onBlur={() => setFieldTouched('password')}
                                    touched={touched.password}
                                    errors={errors.password}
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.password && errors.password ? 'red' : colors.InputGray_Border, }}
                                    secureTextEntry={isVisible}
                                    icon={isVisible ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible(!isVisible)} />


                                <BtnComp title="Next" onPress={handleSubmit} btnStyle={{ marginTop: vs(40), marginBottom: vs(10) }} />
                            </>
                        )}
                    </Formik>
                </View>
            </KeyboardAwareScrollView>
        </View>

    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default SignUp;
