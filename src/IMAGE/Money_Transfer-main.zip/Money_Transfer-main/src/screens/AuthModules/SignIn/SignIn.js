import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, Pressable, ScrollView, TextInput } from 'react-native';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';
import BtnComp from '../../../components/BtnComp';
import { fonts } from '../../../assets/fonts/Fonts';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import { useNavigation } from '@react-navigation/native';
import { fs, hs, screenHeight, screenWidth, vs } from '../../../utility/ResponsiveStyle';
import { AppStack } from '../../../navigators/NavActions';
import { Formik } from 'formik';
import { loginValidate } from '../../../utility/Validations';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import { SigninApi } from '../../../featurers/authSlice';
import { useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SignIn = () => {

    const navigation = useNavigation()
    const [isVisible, setVisible] = useState(true);
    const [user, setUser] = useState();
    const dispatch = useDispatch();

    useEffect(() => {
        GoogleSignin.configure()
    }, []);

    const signIn = async () => {
        try {
            await GoogleSignin.hasPlayServices();
            const userInfo = await GoogleSignin.signIn();
            setUser({ userInfo });
        } catch (error) {
            if (error.code === statusCodes.SIGN_IN_CANCELLED) {

            } else if (error.code === statusCodes.IN_PROGRESS) {

            } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {

            } else {

            }
        }
    };
    
    const token = AsyncStorage.getItem('token')

    const signinHandler = async (values) => {

        let formData = new FormData();
        formData.append('username', values.username);
        formData.append('password', values.password);
        formData.append('rolle', 'user');
        // formData.append('fcm_token', fcmToken);

        console.log("form---", formData)

        let result = await fetch('https://chessmafia.com/php/ankit/n-joo-transfer/App/api/login', {
            method: 'POST',
            headers: {
                "Accept": "application/json",
                "Content-Type": "multipart/form-data",
                'consumer-access-token': token
            },
            body: formData
        })
        const json = await result.json();
            console.log(json)

        if (json?.status == 'Success') {
            navigation.dispatch(AppStack);
        }



        // const response = await dispatch(SigninApi({ data: formData })).unwrap();
        // console.log("responseOfLogin ->", response);

        // if (response?.status == 'Success') {
        //     // dispatch(getValues(true));
        //     // dispatch(saveUser({ ...response.data }));
        //     navigation.dispatch(AppStack);
        // }
    }


    return (
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ width: '95%', alignSelf: 'center', }}>

                    <Image source={images.applogo_login} resizeMode='contain'
                        style={{
                            height: screenHeight * 0.30,
                            width: screenWidth * 0.55,
                            alignSelf: 'center',
                            marginTop: vs(10)
                        }} />

                    <Text style={{ color: colors.Black, fontSize: fs(24), fontWeight: '700', fontFamily: fonts.bold, }}>Sign In</Text>

                    <Formik
                        initialValues={loginValidate.initialState}
                        validationSchema={loginValidate.schema}
                        onSubmit={(values) => signinHandler(values)}
                    >
                        {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                            <>
                                <TextInputWithLabel
                                    placeHolder={'Email'}
                                    value={values.username}
                                    onChangeText={handleChange("username")}
                                    onBlur={() => setFieldTouched('username')}
                                    touched={touched.username}
                                    errors={errors.username}
                                    autoCapitalize='none'
                                    keyboardType='email-address'
                                    inputStyle={{ marginTop: vs(20), borderColor: touched.username && errors.username ? 'red' : colors.InputGray_Border, }}
                                />

                                <TextInputWithLabel
                                    placeholder={'Password'}
                                    value={values.password}
                                    onChangeText={handleChange("password")}
                                    onBlur={() => setFieldTouched('password')}
                                    touched={touched.password}
                                    errors={errors.password}
                                    secureTextEntry={isVisible}
                                    icon={isVisible ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible(!isVisible)}
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.password && errors.password ? 'red' : colors.InputGray_Border, }}
                                /> 

                              
                                 <BtnComp title="Sign In" onPress={handleSubmit} btnStyle={styles.btnStyle} />
                            </>
                        )}
                    </Formik>

                    <Pressable onPress={() => navigation.navigate('ForgotPassword')}>
                        <Text style={{ fontFamily: fonts.bold, color: colors.Black, alignSelf: 'center', marginTop: vs(25), fontSize: fs(18) }}>Forgot Password?</Text>
                    </Pressable>

                    <View style={{ marginTop: vs(20), flexDirection: 'row', width: '95%', justifyContent: 'space-between', alignItems: 'center', alignSelf: 'center' }}>
                        <View style={{ borderWidth: 1, opacity: 0.5, width: '45%', borderColor: colors.InputGray_Border, }} />
                        <Text style={{ fontSize: fs(16), color: colors.Graytab_footer, }}>OR</Text>
                        <View style={{ borderWidth: 1, opacity: 0.5, width: '45%', borderColor: colors.InputGray_Border, }} />
                    </View>

                    <Pressable style={styles.google_btn} onPress={signIn}>
                        <Image source={images.googleIcon} resizeMode='contain'
                            style={{ height: vs(35), width: hs(35) }} />
                        <Text style={{ fontFamily: fonts.semiBold, marginLeft: hs(10), color: colors.Black, fontSize: fs(18) }}>Login with google</Text>
                    </Pressable>
                </View>

                <View style={{ marginTop: vs(30), alignSelf: 'center', flexDirection: 'row', marginBottom: vs(20) }}>
                    <Text style={{ fontSize: fs(16), color: colors.GreyText }}>Don't have an account? </Text>

                    <Pressable onPress={() => navigation.navigate('SignUp')}>
                        <Text style={{ color: colors.PrimaryBlue, textDecorationLine: 'underline', fontWeight: '700', fontSize: fs(16) }}>Sign Up</Text>
                    </Pressable>
                </View>

            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
    btnStyle: {
        marginTop: vs(25)
    },
    google_btn: {
        width: '100%',
        alignSelf: 'center',
        backgroundColor: colors.white,
        height: vs(55),
        borderRadius: 25,
        alignItems: 'center',
        flexDirection: 'row',
        borderWidth: fs(1),
        borderColor: colors.InputGray_Border,
        paddingHorizontal: hs(15),
        marginTop: vs(25)
    }
});

export default SignIn;
