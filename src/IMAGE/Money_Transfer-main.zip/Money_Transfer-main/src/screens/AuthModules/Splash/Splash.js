import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image, } from 'react-native';
import { images } from '../../../assets/images';
import { useNavigation } from '@react-navigation/native';


const Splash = () => {

    const navigation = useNavigation();

       useEffect(()=>{ 
          setTimeout(()=>{
                navigation.navigate('AppIntro')
          },3000);
       },[])

    return (
        <View style={styles.container}>
            <Image source={images.applogo} resizeMode='contain'
                style={styles.splashImage} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white"
    },
    splashImage: {
        width: '100%',
        height: "100%",
    },
});

export default Splash;
