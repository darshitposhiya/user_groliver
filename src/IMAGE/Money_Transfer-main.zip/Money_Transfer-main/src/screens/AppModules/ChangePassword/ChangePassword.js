import React, { useLayoutEffect, useState } from 'react';
import { View, Text, StyleSheet, } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { useNavigation } from '@react-navigation/native';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import HeaderComp from '../../../components/HeaderComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import { Formik } from 'formik';
import { changePasswordValidate } from '../../../utility/Validations';
import BtnComp from '../../../components/BtnComp';

const ChangePassword = () => {

    const navigation = useNavigation();
    const [isVisible1, setVisible1] = useState(true);
    const [isVisible2, setVisible2] = useState(true);
    const [isVisible3, setVisible3] = useState(true);

    const renderHeader = () => {
        return (
            <HeaderComp heading="Change password" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const changePasswordHandler = (data) => {

        console.log("changep_w", data)
        navigation.goBack()
    }
    return (
        <View style={styles.container}>
            <KeyboardAwareScrollView>
                <View style={{ width: '95%', alignSelf: 'center' }}>
                    <Formik
                        initialValues={changePasswordValidate.initialState}
                        validationSchema={changePasswordValidate.schema}
                        onSubmit={(values) => changePasswordHandler(values)}
                    >
                        {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                            <>
                                <TextInputWithLabel
                                    placeholder={'Current password'}
                                    value={values.old_password}
                                    onChangeText={handleChange("old_password")}
                                    onBlur={() => setFieldTouched('old_password')}
                                    touched={touched.old_password}
                                    secureTextEntry={isVisible1}
                                    inputStyle={{ marginTop: vs(20), borderColor: touched.old_password && errors.old_password ? 'red' : colors.InputGray_Border }}
                                    icon={isVisible1 ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible1(!isVisible1)}
                                />

                                <TextInputWithLabel
                                    placeholder={'New password'}
                                    value={values.password}
                                    onChangeText={handleChange("password")}
                                    onBlur={() => setFieldTouched('password')}
                                    touched={touched.password}
                                    secureTextEntry={isVisible2}
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.password && errors.password ? 'red' : colors.InputGray_Border }}
                                    icon={isVisible2 ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible2(!isVisible2)}
                                />

                                <TextInputWithLabel
                                    placeholder={'Confirm password'}
                                    value={values.confirmPassword}
                                    onChangeText={handleChange("confirmPassword")}
                                    onBlur={() => setFieldTouched('confirmPassword')}
                                    touched={touched.confirmPassword}
                                    secureTextEntry={isVisible3}
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.confirmPassword && errors.confirmPassword ? 'red' : colors.InputGray_Border }}
                                    icon={isVisible3 ? images.hide_psw : images.visible_psw}
                                    onPressIcon={() => setVisible3(!isVisible3)}
                                />

                                <BtnComp title="Save" onPress={handleSubmit} btnStyle={{ marginTop: vs(25) }} />
                            </>
                        )}
                    </Formik>
                </View>
            </KeyboardAwareScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default ChangePassword;
