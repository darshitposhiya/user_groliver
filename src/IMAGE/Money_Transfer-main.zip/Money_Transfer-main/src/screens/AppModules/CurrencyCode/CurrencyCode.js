import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import InputComp from '../../../components/InputComp';
import { colors } from '../../../assets/colors/Colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import CountryCurrencyArray from '../../../CountryCurrencyCode.json';
import CurrecyCodeLists from '../../../components/ListViews/CurrencyCodeLists/CurrencyCodeLists';
import { useDispatch } from 'react-redux';
import { setCountryCurrency } from '../../../featurers/dashbordSlice';
import { hs,screenWidth, vs } from '../../../utility/ResponsiveStyle';

const CurrencyCode = ({route}) => {

    const navigation = useNavigation();
    const dispatch = useDispatch();
    const [search, setSearch] = useState('');
    const [searchedCurrency, setSearchedCurrency] = useState([]);

    useEffect(() => { setSearchedCurrency(CountryCurrencyArray); }, []);
    useEffect(() => {
        if (search) {
            searchHandler();
        }
    }, [search]);

    const searchHandler = () => {
        let text = search.toLowerCase();
        let countries = CountryArray.filter((item, index) => {
            return item?.currency_code?.includes(search) || item?.currency_code?.toLowerCase().includes(text) || item?.country?.toLowerCase().includes(text);
            // return item.name.toLowerCase().includes( text ) || item.code == search;
        });
        setSearchedCurrency(countries);
    };

    const _renderCountry = ({ item, index }) => {
        return <CurrecyCodeLists
            {...item}
            goToCountry={() => {
                dispatch(setCountryCurrency(item.currency_code));
                navigation.navigate({
                    name: route?.params?.fromSendingMoney == true ? 'SendToCountry' : null,
                    params: { country_currency: item.currency_code },
                    merge: true
                });
            }}
        />;
    };

    const renderHeader = () => {
        return (
            <View style=
                {{
                    backgroundColor: colors.white,
                    height: 30,
                    paddingHorizontal: hs(10),
                    flexDirection: 'row',
                    alignItems: 'flex-end',
                    marginBottom:vs(10)
                }}>

                {/* <Ionicons
                    name=''
                    size={30}
                    color='grey'
                    onPress={() => { navigation.goBack(); }}
                /> */}
                <InputComp
                    placeHolder="search with country code etc..."
                    value={search}
                    onChangeText={setSearch}
                    input_view={{
                        borderWidth: 0,
                        borderBottomWidth: 1,
                        width:'95%',
                        alignSelf:'center',
                        marginTop: -10,
                    }} />
            </View>
        )
    }

    return (
        <View style={{ flex: 1, backgroundColor: colors.white }}>
            {renderHeader()}
            <FlatList
                data={searchedCurrency}
                renderItem={_renderCountry}
                initialNumToRender={15}
                removeClippedSubviews={true}
                keyExtractor={(_, index) => index.toString()}
                getItemLayout={(data, index) => (
                    { length: 50, offset: 50 * index, index }
                )}
            />
        </View>
    );
};


export default CurrencyCode;
