import React, { useLayoutEffect, useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, Pressable, FlatList } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { useNavigation } from '@react-navigation/native';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import HeaderComp from '../../../components/HeaderComp';
import { AppStack } from '../../../navigators/NavActions';
import AllCountriesArray from '../../../AllCountriesArray.json';
import AllCountriesLists from '../../../components/ListViews/AllCountriesLists/AllCountriesLists';

const SendMoney = () => {

    const navigation = useNavigation();
    const [search, setSearch] = useState('');
    const [countryLists, setCountryLists] = useState([]);

    useEffect(() => { setCountryLists(AllCountriesArray); }, []);
    useEffect(() => {
        if (search) {
            searchHandler();
        }
    }, [search]);


    const searchHandler = () => {
        let text = search.toLowerCase();
        let country = AllCountriesArray.filter((item, index) => {
            return item?.currency_code?.includes(search) || item?.currency_code?.toLowerCase().includes(text) || item?.country?.toLowerCase().includes(text);
        });
        setCountryLists(country);
    };

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.dispatch(AppStack)} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const _renderAllCountries = ({ item }) => {
        return <AllCountriesLists {...item} />
    }

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>
                <Text style={{ fontSize: fs(22), color: colors.Black, fontWeight: '700', marginTop: vs(20) }}>Where are you sending?</Text>

                <TextInputWithLabel
                    placeHolder={"search"}
                    value={search}
                    onChangeText={setSearch}
                    inputStyle={{ marginTop: vs(15) }}
                    icon={images.search}
                />

                <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '600', marginTop: vs(15) }}>Most frequent</Text>

                <View style={{ marginTop: vs(15) }}>
                    <FlatList
                        data={countryLists}
                        renderItem={_renderAllCountries}
                        initialNumToRender={15}
                        removeClippedSubviews={true}
                        keyExtractor={(_, index) => index.toString()}
                        getItemLayout={(data, index) => (
                            { length: 50, offset: 50 * index, index }
                        )}
                        showsVerticalScrollIndicator={false}
                        contentContainerStyle={{
                            paddingBottom: vs(50)
                        }}
                    />
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default SendMoney;
