import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import InputComp from '../../../components/InputComp';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import BtnComp from '../../../components/BtnComp';
import HeaderComp from '../../../components/HeaderComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview'
import { AppStack } from '../../../navigators/NavActions';
import { Formik } from 'formik';
import { recipientDetailsValidate } from '../../../utility/Validations';

const RecipientDetails = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.dispatch(AppStack)} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const recipientDetailsHandler = (data) => {

        console.log(data, "recipientdetail")
         navigation.navigate('TransactionSummary')
    }

    return (
        <View style={styles.container}>
            <Formik
                initialValues={recipientDetailsValidate.initialState}
                validationSchema={recipientDetailsValidate.schema}
                onSubmit={(values) => recipientDetailsHandler(values)}
            // innerRef={formRef}
            >
                {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                    <>
                        <KeyboardAwareScrollView>
                            <View style={{ width: '95%', alignSelf: 'center' }}>

                                <Text style={{ marginTop: vs(20), color: colors.Black, fontSize: fs(20), fontWeight: '700' }}>Recipient Details</Text>

                                <InputComp
                                    placeholder={'Country'}
                                    value={values.country}
                                    onChangeText={handleChange("country")}
                                    onBlur={() => setFieldTouched('country')}
                                    touched={touched.country}
                                    errors={errors.country}
                                    //editable={false}
                                    input_view={{ marginTop: vs(20), borderColor: touched.country && errors.country ? 'red' : colors.InputGray_Border, }} />

                                <InputComp
                                    placeholder={'City'}
                                    value={values.city}
                                    onChangeText={handleChange("city")}
                                    onBlur={() => setFieldTouched('city')}
                                    touched={touched.city}
                                    errors={errors.city}
                                    input_view={{ marginTop: vs(15), borderColor: touched.city && errors.city ? 'red' : colors.InputGray_Border, }} />

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                                    <View style={{ width: '49%' }}>
                                        <TextInputWithLabel
                                            placeholder={'First name'}
                                            value={values.f_name}
                                            onChangeText={handleChange("f_name")}
                                            onBlur={() => setFieldTouched('f_name')}
                                            touched={touched.f_name}
                                            errors={errors.f_name}
                                            inputStyle={{ borderColor: touched.f_name && errors.f_name ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <TextInputWithLabel
                                            placeholder={'Last name'}
                                            value={values.l_name}
                                            onChangeText={handleChange("l_name")}
                                            onBlur={() => setFieldTouched('l_name')}
                                            touched={touched.l_name}
                                            errors={errors.l_name}
                                            inputStyle={{ borderColor: touched.l_name && errors.l_name ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                                    <View style={{ width: '25%' }}>
                                        <InputComp
                                            placeholder={'+27'}
                                            // editable={false}
                                            // value={route?.params?.phone_code}
                                            pointerEvents="box-only"
                                            input_view={{ borderColor: touched.country && errors.country ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '73%' }}>
                                        <InputComp
                                            placeholder={'Phone number'}
                                            value={values.phone}
                                            onChangeText={handleChange("phone")}
                                            onBlur={() => setFieldTouched('phone')}
                                            touched={touched.phone}
                                            errors={errors.phone}
                                            input_view={{ borderColor: touched.phone && errors.phone ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder={'Email address (Optional)'}
                                    value={values.email}
                                    onChangeText={handleChange("email")}
                                    onBlur={() => setFieldTouched('email')}
                                    touched={touched.email}
                                    inputStyle={{ marginTop: vs(15), }} />


                                <View style={{ marginTop: vs(140), marginBottom: vs(10) }}>
                                    <Text style={{ fontSize: fs(14), color: colors.Black, fontWeight: '700', textAlign: 'justify' }}>Important: <Text style={{ fontWeight: '400' }}>Lorem ipsum is simply dummy text of the printing and typesetting industry.</Text></Text>
                                </View>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: vs(10) }}>
                                    <BtnComp onPress={() => navigation.goBack()} title="Back" btnStyle={styles.white_btn} btnTextStyle={{ color: colors.Black }} />
                                    <BtnComp onPress={handleSubmit} title="Next" btnStyle={{ width: '49%' }} />
                                </View>
                            </View>
                        </KeyboardAwareScrollView>
                    </>
                )}
            </Formik>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
    white_btn: {
        width: '49%',
        backgroundColor: colors.white,
        borderWidth: 1,
        borderColor: colors.InputGray_Border
    }
});

export default RecipientDetails;
