import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, Pressable } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { fs, screenHeight, screenWidth, vs, hs } from '../../../utility/ResponsiveStyle';
import { useNavigation } from '@react-navigation/native';
import { AppStack } from '../../../navigators/NavActions';

const ReceiptCreated = () => {

    const navigation = useNavigation();

    return (
        <View style={styles.container}>
            <Image source={images.success}
                style={{ height: screenHeight * 0.15, width: screenWidth * 0.30, resizeMode: 'contain' }} />

            <Text style={{ marginTop: vs(15), fontSize: fs(22), color: colors.Black, fontWeight: '700' }}>Receipt created</Text>
            <Text style={{ marginTop: vs(10), fontSize: fs(16), color: colors.Black }}>Your transaction has been successfully</Text>
            <Text style={{ fontSize: fs(16), color: colors.Black }}>registered.</Text>

            <View style={{ width: '90%', alignItems: 'center', justifyContent: 'center', alignSelf: 'center', borderWidth: 1, borderRadius: 5, backgroundColor: '#ECF9FF', borderColor: '#0B96D9', padding: vs(15), marginTop: vs(10) }}>
                <Text style={{ fontSize: fs(16), color: colors.Black }}>Transaction code</Text>
                <Text style={{ marginTop: vs(5), fontSize: fs(26), color: colors.Black, fontWeight: '700' }} >6279-2176-4b49-6</Text>
            </View>

            <Pressable onPress={() => navigation.dispatch(AppStack)}>
                <Text style={{ fontSize: fs(16), color: '#2764A2', marginTop: vs(10) }}>Back to home</Text>
            </Pressable>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.white
    },
});

export default ReceiptCreated;
