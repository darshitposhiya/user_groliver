import React, { useLayoutEffect, useState } from 'react';
import { View, Text, StyleSheet, Switch } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';
import { fonts } from '../../../assets/fonts/Fonts';

const AccountSetting = () => {

    const navigation = useNavigation();

    const [isPushNotification, setIsPushNotification] = useState(false);
    const [isEmailNotification, setIsEmailNotifications] = useState(false);
    const [isWhatsAppNotification, setIsWhatsAppNotification] = useState(false);

    const renderHeader = () => {
        return (
            <HeaderComp heading="Account setting" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);
    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(20) }}>
                    <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '500', fontFamily: fonts.semiBold }}>Push notifications</Text>
                    <Switch
                        trackColor={{ false: '#D9D9D9', true: '#34A853' }}
                        ios_backgroundColor="#3e3e3e"
                        thumbColor={isPushNotification ? '#fff' : '#FFFFFF'}
                        value={isPushNotification == 1 ? true : false} />
                </View>
                <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                    <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '500', fontFamily: fonts.semiBold }}>Email notifications</Text>
                    <Switch
                        trackColor={{ false: '#D9D9D9', true: '#34A853' }}
                        ios_backgroundColor="#3e3e3e"
                        thumbColor={isEmailNotification ? '#fff' : '#FFFFFF'}
                        value={isEmailNotification == 1 ? true : false} />
                </View>
                <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                    <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '500', fontFamily: fonts.semiBold }}>Whatsapp notifications</Text>
                    <Switch
                        trackColor={{ false: '#D9D9D9', true: '#34A853' }}
                        ios_backgroundColor="#3e3e3e"
                        thumbColor={isWhatsAppNotification ? '#fff' : '#FFFFFF'}
                        value={isWhatsAppNotification == 1 ? true : false} />
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default AccountSetting;
