import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, Pressable, ImageBackground, Image } from 'react-native';
import { vs, hs, fs, screenHeight } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import { images } from '../../../assets/images';
import { AuthStack } from '../../../navigators/NavActions';
import { getStatusBarHeight } from '../../../utility/Globals';

const Account = () => {

    const navigation = useNavigation();
    const statusBarHeight = getStatusBarHeight();

    const renderHeader = () => {
        return (
            <View style={{ width: '100%', backgroundColor: colors.white, paddingTop: statusBarHeight }}>
                <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10), }}>
                    <Text style={{ fontSize: fs(26), color: colors.Black, fontWeight: '700' }}>Account</Text>
                </View>
            </View>

        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>

                <View style={{ borderRadius: 10, height: screenHeight * 0.20, width: '100%', marginTop: vs(20) }}>
                    <ImageBackground source={images.bg} resizeMode='stretch' style={{ width: '100%', height: '100%', justifyContent: 'center' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: hs(10), }}>
                            <View>
                                <Text style={{ fontSize: fs(18), color: colors.white, fontWeight: '700' }}>Roady Clark</Text>
                                <Text style={{ fontSize: fs(14), color: colors.white, marginTop: vs(3) }}>roadyclark@gmail.com</Text>
                            </View>

                            <Pressable onPress={() => navigation.navigate('EditProfile')} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: vs(5), borderWidth: 1, borderColor: colors.white, borderRadius: 5 }}>
                                <Text style={{ fontSize: fs(14), color: colors.white }}>Edit profile</Text>
                                <Image source={images.right_arrow}
                                    style={{ height: vs(10), width: hs(20), resizeMode: 'contain', marginLeft: hs(5) }} />
                            </Pressable>
                        </View>
                    </ImageBackground>
                </View>

                <View style={{ marginTop: vs(5) }}>
                    <Row_Box onPress={() => navigation.navigate('AccountSetting')} image={images.ac_setting} title="Account setting" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box onPress={() => navigation.navigate('Faq')} image={images.faq} title="FAQ" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box onPress={() => navigation.navigate('ChangePassword')} image={images.change_psw} title="Change password" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box onPress={() => navigation.navigate('TermsAndConditions')} image={images.terms} title="Terms and conditions" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box onPress={() => navigation.dispatch(AuthStack)} image={images.logout} title="Logout" />
                </View>
            </View>
        </View>
    );
};

const Row_Box = (
    {
        onPress,
        image,
        title,
    }
) => {
    return (
        <Pressable onPress={onPress} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Image source={image} style={{ height: vs(20), width: hs(20), resizeMode: 'contain' }} />
                <Text style={{ fontSize: fs(16), color: colors.Black, marginHorizontal: hs(10) }}>{title}</Text>
            </View>
            <Image source={images.right} style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />
        </Pressable>

    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default Account;
