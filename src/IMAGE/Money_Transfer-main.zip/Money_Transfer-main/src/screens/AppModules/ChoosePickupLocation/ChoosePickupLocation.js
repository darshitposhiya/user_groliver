import React, { useLayoutEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { useNavigation } from '@react-navigation/native';
import PickUpItemsLists from '../../../components/ListViews/PickUpItemsLists/PickUpItemsLists';
import BtnComp from '../../../components/BtnComp';
import HeaderComp from '../../../components/HeaderComp';
import { AppStack } from '../../../navigators/NavActions';

const ChoosePickupLocation = () => {

    const PickupData = [
        {
            name: "Banque Atantique",
            time1: "Monday to Friday: 7:30 AM-5:30 PM",
            time2: "Saturday: 9:30 AM-4:30 PM"
        },
        {
            name: "First Trust",
            time1: "Monday to Friday: 7:30 AM-5:30 PM",
            time2: "Saturday: 9:30 AM-4:30 PM"
        },
    ]
    const navigation = useNavigation();
    const [select, setSelect] = useState(false);

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.dispatch(AppStack)} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const _renderPickupItems = ({ item }) => {
        return <PickUpItemsLists {...item}
        // selectHandler={() => {
        //     setSelect(item)
        // }}
        />
    }

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>

                <Text style={{ marginTop: vs(20), color: colors.Black, fontSize: fs(20), fontWeight: '700' }}>Choose pickup location</Text>

                <View style={{ marginTop: vs(5) }}>
                    <FlatList
                        data={PickupData}
                        renderItem={_renderPickupItems}
                        keyExtractor={(_, index) => index.toString()}
                        showsVerticalScrollIndicator={false}
                    />
                </View>
            </View>

            <View style={{ width: '95%', alignSelf: 'center', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', position: 'absolute', bottom: vs(10) }}>
                <BtnComp onPress={() => navigation.goBack()} title="Back" btnStyle={styles.white_btn} btnTextStyle={{ color: colors.Black }} />
                <BtnComp onPress={() => navigation.navigate('RecipientDetails')} title="Next" btnStyle={{ width: '49%' }} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
    white_btn: {
        width: '49%',
        backgroundColor: colors.white,
        borderWidth: 1,
        borderColor: colors.InputGray_Border
    }
});

export default ChoosePickupLocation;
