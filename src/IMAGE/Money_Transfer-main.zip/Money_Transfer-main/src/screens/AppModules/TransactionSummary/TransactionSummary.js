import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { vs, hs, fs, } from '../../../utility/ResponsiveStyle';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import BtnComp from '../../../components/BtnComp';
import HeaderComp from '../../../components/HeaderComp';
import { AppStack } from '../../../navigators/NavActions';

const TransactionSummary = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.dispatch(AppStack)} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    return (
        <View style={styles.container}>
            <ScrollView nestedScrollEnabled={true} showsVerticalScrollIndicator={false} style={{ paddingBottom: vs(20) }}>
                <View style={{ width: '95%', alignSelf: 'center' }}>
                    <Text style={{ marginTop: vs(20), color: colors.Black, fontSize: fs(20), fontWeight: '700' }}>Transaction summary</Text>

                    <Row_Container1 firstText="Roady Clark" secondText="Pickup: Banque Atantique" ContainerStyle={{ marginTop: vs(20) }} />
                    <Row_Container1 firstText="You are sending" secondText="1,000 ERU" />
                    <Row_Container1 firstText="Contact receives" secondText="638,234 XAF" />

                    <Row_View leftText="Exchange rate:" rightText="1 EUR = 638.2340 XAF" ViewStyle={{ marginTop: vs(20) }} />
                    <Row_View leftText="Fee:" rightText="2.99 EUR" />
                    <Row_View leftText="Total you pay:" rightText="1,002.99 EUR" />

                    <View style={{ borderWidth: 1, opacity: 0.5, borderColor: colors.InputGray_Border, marginTop: vs(20) }} />

                    <Text style={{ fontSize: fs(16), color: colors.Black, marginTop: vs(20), paddingBottom: vs(80) }}>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</Text>
                </View>

                <BtnComp onPress={() => navigation.navigate('ReceiptCreated')} title="Send" btnStyle={{ width: '95%', alignSelf: 'center', marginBottom: vs(10) }} />
            </ScrollView>
        </View>
    );
};

const Row_Container1 = ({
    firstText,
    secondText,
    ContainerStyle
}) => {
    return (
        <View style={{ ...styles.Row_Con1_View, ...ContainerStyle }}>
            <View>
                <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '600' }}>{firstText}</Text>
                <Text style={{ fontSize: fs(16), color: colors.Black, marginTop: vs(3) }}>{secondText}</Text>
            </View>

            <Image source={images.right}
                style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />
        </View>
    )
}

const Row_View = ({
    leftText,
    rightText,
    ViewStyle,
}) => {
    return (
        <View style={{ ...styles.RowView, ...ViewStyle }}>
            <Text style={{ fontSize: fs(16), color: colors.Black }}>{leftText}</Text>
            <Text style={{ fontSize: fs(16), color: colors.Black }}>{rightText}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
    Row_Con1_View: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderWidth: 1,
        borderRadius: 5,
        borderColor: colors.InputGray_Border,
        paddingVertical: vs(10),
        paddingHorizontal: hs(10),
        marginTop: vs(15)
    },
    RowView: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: vs(15)
    }
});

export default TransactionSummary;
