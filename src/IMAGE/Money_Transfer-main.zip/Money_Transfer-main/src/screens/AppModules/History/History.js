import React, { useLayoutEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { vs, hs, fs, screenWidth } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import BtnComp from '../../../components/BtnComp';
import HistoryLists from '../../../components/ListViews/HistoryLists/HistoryLists';
import CompleteHistoryLists from '../../../components/ListViews/CompleteHistoryLists/CompleteHistoryLists';
import { getStatusBarHeight } from '../../../utility/Globals';

const History = () => {

    const PendingHistroy = [
        {
            name: "Jenny Arthur",
            date: "23 Mar 2023",
            amount: "200.2 GBP"
        },
        {
            name: "Michel Ortege",
            date: "28 Mar 2023",
            amount: "50.00 EUR"
        },
    ]

    const CompleteHistory = [
        {
            name: "Jenny Arthur",
            date: "23 Mar 2023",
            amount: "200.2 GBP"
        },
        {
            name: "Michel Ortege",
            date: "27 Mar 2023",
            amount: "1000.00 EUR"
        },
        {
            name: "Michel Obama",
            date: "25 Mar 2023",
            amount: "100.00 GBP"
        },
        {
            name: "Jonney Lever",
            date: "21 Mar 2023",
            amount: "100.00 GBP"
        },
    ]

    const navigation = useNavigation();
    const statusBarHeight = getStatusBarHeight();
    const [isFinished, setIsFinished] = useState(true);

    const renderHeader = () => {
        return (
            <View style={{ width: '100%', backgroundColor: colors.white, paddingTop: statusBarHeight }}>
                <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10), }}>
                    <Text style={{ fontSize: fs(26), color: colors.Black, fontWeight: '700' }}>History</Text>
                </View>
            </View>

        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const _renderPendingHistoryLists = ({ item }) => {
        return <HistoryLists {...item} />
    }

    const _renderCompleteHistoryLists = ({ item }) => {
        return <CompleteHistoryLists {...item} />
    }

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center' }}>

                <View style={{
                    marginTop: vs(20),
                    height: vs(41.5),
                    width: screenWidth * 0.71,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    borderWidth: 1,
                    borderRadius: 50,
                    borderColor: colors.InputGray_Border
                }}>
                    <BtnComp title="Pending" onPress={() => setIsFinished(true)}
                        btnStyle={{
                            width: screenWidth * 0.35,
                            height: vs(40),
                            borderRadius: 50,
                            backgroundColor: isFinished == false ? 'white' : colors.Lightblue
                        }}
                        btnTextStyle={{ color: isFinished ? colors.white : colors.Black, fontSize: fs(16) }} />

                    <BtnComp title="Complete" onPress={() => setIsFinished(false)}
                        btnStyle={{
                            width: screenWidth * 0.35,
                            height: vs(40),
                            borderRadius: 50,
                            backgroundColor: isFinished == true ? 'white' : colors.Lightblue
                        }}
                        btnTextStyle={{ color: isFinished ? colors.Black : colors.white, fontSize: fs(16) }} />
                </View>

                <View style={{ marginTop: vs(5), marginBottom: vs(130) }}>
                    {
                        isFinished == true ?

                            (<FlatList
                                data={PendingHistroy}
                                renderItem={_renderPendingHistoryLists}
                                keyExtractor={(_, index) => index.toString()}
                                contentContainerStyle={{ paddingBottom: vs(20) }}
                                showsVerticalScrollIndicator={false}
                            />)
                            :
                            (<FlatList
                                data={CompleteHistory}
                                renderItem={_renderCompleteHistoryLists}
                                keyExtractor={(_, index) => index.toString()}
                                contentContainerStyle={{ paddingBottom: vs(20) }}
                                showsVerticalScrollIndicator={false}
                            />)
                    }
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
});

export default History;
