import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import NotificationsLists from '../../../components/ListViews/NotificationsLists/NotificationsLists';
import { getStatusBarHeight } from '../../../utility/Globals';

const Alerts = () => {

    const NotificationData = [
        {
            title: "Title",
            detail: "Lorem ipsum is simply dummy text of the printing industry.",
            time: "1h ago",
        },
        {
            title: "Title",
            detail: "Lorem ipsum is simply dummy text of the printing industry.",
            time: "1h ago",
        },
        {
            title: "Title",
            detail: "Lorem ipsum is simply dummy text of the printing industry.",
            time: "1h ago",
        },
        {
            title: "Title",
            detail: "Lorem ipsum is simply dummy text of the printing industry.",
            time: "1h ago",
        },
    ]
    const navigation = useNavigation();
    const statusBarHeight = getStatusBarHeight();

    const renderHeader = () => {
        return (
            <View style={{ width: '100%', backgroundColor: colors.white, paddingTop: statusBarHeight }}>
                <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10), }}>
                    <Text style={{ fontSize: fs(26), color: colors.Black, fontWeight: '700' }}>Notifications</Text>
                </View>
            </View>

        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const _renderNotificationsLists = ({ item }) => {
        return <NotificationsLists {...item} />
    }

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10) }}>
                <FlatList
                    data={NotificationData}
                    renderItem={_renderNotificationsLists}
                    keyExtractor={(_, index) => index.toString()}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={{ paddingBottom: vs(20) }}
                />
            </View>
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default Alerts;
