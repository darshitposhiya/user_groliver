import React, { useLayoutEffect, useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Image, Pressable, Modal, Alert } from 'react-native';
import { vs, hs, fs, screenHeight, screenWidth } from '../../../utility/ResponsiveStyle';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import InputComp from '../../../components/InputComp';
import BtnComp from '../../../components/BtnComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview'
import HeaderComp from '../../../components/HeaderComp';
import { AppStack } from '../../../navigators/NavActions';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';


const SendToCountry = ({ route }) => {

    const navigation = useNavigation();
    const transactionFeeRef = useRef();
    const formRef = useRef();
    const [modalVisible, setModalVisible] = useState(false);
    const [exchangeRate, setExchangeRate] = useState('');
    const [amount, setAmount] = useState('');

    const exchangeRateAmount = amount * exchangeRate;

    useEffect(() => {
        const apiUrl = `https://api.exchangerate-api.com/v4/latest/${route?.params?.country_currency}`;
        axios.get(apiUrl).then((response) => {
            const rate = response.data.rates[route?.params?.currencyCode];
            setExchangeRate(rate);
        });
    }, [route?.params?.country_currency, route?.params?.currencyCode]);

    useEffect(() => {
        if (formRef.current) {
            formRef.current?.setFieldValue('sender_country', route.params?.country_currency || '');
        }
    }, [formRef, route.params]);

    const selectCountryCurrency = () => {
        navigation.navigate('CurrencyCode', {
            fromSendingMoney: true
        });
    }

    let token = AsyncStorage.getItem('token')

    const sendingMoneyToCountryHandler = async () => {
        let formData = new FormData();
        formData.append('sender_country', route.params?.country_currency);
        formData.append('receiver_country', route?.params?.currencyCode);
        formData.append('sender_amount', amount);
        formData.append('receiver_amount', exchangeRateAmount?.toFixed(2));
        formData.append('xvalue_amount', exchangeRate);
        formData.append('fees', exchangeRate);

        console.log(formData, "------")
        let response = await fetch('https://chessmafia.com/php/ankit/n-joo-transfer/App/api/send-money-request', {
            method: 'POST',
            headers: {
                "Accept": "application/json",
                "Content-Type": "multipart/form-data",
                'consumer-access-token': token
            },
            body: formData
        })
        const json = await response.json();
        console.log("json--", json)

        if (amount == null || route.params?.country_currency == null || response?.status == "Error") {
            Alert.alert("Field is empty");
        }
        else if (json?.status == 'Success') {
            navigation.navigate("ChoosePickupLocation");
        }
    }

    const renderHeader = () => {
        return (
            <HeaderComp onPress={() => navigation.dispatch(AppStack)} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    return (
        <View style={styles.container}>
            <KeyboardAwareScrollView>
                <View style={{ width: '95%', alignSelf: 'center' }}>

                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: vs(20) }}>
                        <Text style={{ fontSize: fs(20), fontWeight: '700', color: colors.Black }}>Sending money to {route?.params?.countryName}</Text>
                        <Pressable>
                            <Text style={{ fontSize: fs(18), color: colors.Lightblue }}>change</Text>
                        </Pressable>
                    </View>

                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: vs(20) }}>
                        <TextInputWithLabel
                            placeHolder='you are sending'
                            value={amount}
                            onChangeText={(val) => setAmount(val)}
                            keyboardType="number-pad"
                            inputStyle={{ width: '73%' }}
                        />

                        <InputComp
                            placeholder={'Ex.ZAR'}
                            value={route?.params?.country_currency}
                            onPress={selectCountryCurrency}
                            input_view={{ width: '25%' }}
                        />
                    </View>

                    <TextInputWithLabel
                        placeholder={exchangeRateAmount?.toFixed(2)}
                        editable={false}
                        rightText={route?.params?.currencyCode}
                        inputStyle={{ marginTop: vs(15) }}
                    />

                    <View style={{ marginTop: vs(20), flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Text style={{ color: colors.Black, fontSize: fs(16) }}>Exchange rate:</Text>
                        <Text style={{ color: colors.Black, fontSize: fs(16) }}>{`1 ${route?.params?.country_currency == undefined ? '' : route?.params?.country_currency} = ${exchangeRate} ${route?.params?.currencyCode}`}</Text>
                    </View>

                    <View style={{ height: vs(1), backgroundColor: colors.InputGray_Border, marginTop: vs(20) }} />

                    <View style={{ marginTop: vs(20), alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ fontSize: fs(16), color: colors.GreyText, textAlign: 'center' }}>lorem text is simply dummy text of the printing and <Text style={{ textAlign: 'center' }}>typesetting industry.</Text></Text>

                        <Pressable onPress={() => setModalVisible(!modalVisible)}>
                            <Text style={{ marginTop: vs(25), alignSelf: 'center', fontSize: fs(18), color: colors.Lightblue, fontWeight: '700' }}>Check fees for this transaction</Text>
                        </Pressable>
                    </View>

                    <Image source={images.applogo1}
                        style={{ height: screenHeight * 0.25, width: screenWidth * 0.30, resizeMode: 'center', alignSelf: 'center', marginTop: vs(40), }} />

                </View>

                <View style={{ width: '95%', alignSelf: 'center', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: vs(10) }}>
                    <BtnComp onPress={() => navigation.goBack()} title="Back" btnStyle={styles.white_btn} btnTextStyle={{ color: colors.Black }} />
                    <BtnComp onPress={sendingMoneyToCountryHandler} title="Next" btnStyle={{ width: '49%' }} />
                </View>
            </KeyboardAwareScrollView>

            {/*Modalbox*/}

            <View style={styles.centeredView}>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={modalVisible}
                >
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>

                            <View style={styles.modelheader_view}>
                                <Text style={{ fontSize: fs(20), fontWeight: '700', color: colors.Black }}>Transaction fees</Text>
                                <Pressable onPress={() => setModalVisible(!modalVisible)}>
                                    <Image source={images.close} resizeMode='contain'
                                        style={styles.close_icon} />
                                </Pressable>
                            </View>

                            <View style={{ height: vs(1), width: '100%', backgroundColor: colors.InputGray_Border, marginVertical: vs(15) }} />

                            <View style={styles.modelheader_view}>
                                <Text style={styles.model_row_text}>paying with</Text>
                                <Text style={styles.model_row_text}>{route?.params?.currencyCode}</Text>
                            </View>

                            <View style={styles.modelheader_view}>
                                <Text style={styles.model_row_text}>Bank amount</Text>
                                <Text style={styles.model_row_text}>{exchangeRate}</Text>
                            </View>

                            <View style={{ width: '95%', alignSelf: 'center', marginVertical: vs(20), }}>
                                <Text style={{ fontSize: fs(16), color: colors.GreyText, textAlign: 'center', alignSelf: 'center' }}>lorem ipsum is dummy text of the printing and <Text>typesetting industry.</Text></Text>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
    white_btn: {
        width: '49%',
        backgroundColor: colors.white,
        borderWidth: 1,
        borderColor: colors.InputGray_Border
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        width: '100%',
    },
    modalView: {
        width: '100%',
        paddingVertical: vs(15),
        paddingHorizontal: hs(10),
        backgroundColor: 'white',
        borderRadius: fs(15),
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    modelheader_view: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '95%',
        alignSelf: 'center',
        marginTop: vs(10),
    },
    close_icon: {
        height: vs(20),
        width: hs(20),
        resizeMode: 'contain',
        marginRight: hs(5)
    },
    model_row_text: {
        fontSize: fs(18),
        color: colors.Black
    }
});

export default SendToCountry;
