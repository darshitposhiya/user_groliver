import React, { useLayoutEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, Pressable, FlatList } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';
//import FAQLists from '../../../components/ListViews/FAQLists/FAQLists';

const Faq = () => {

    const FaqData = [
        {
            id: "1",
            question: "What is lorem Ipsum?",
            answer: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
        },
        {
            id: "2",
            question: "Why do we use it?",
            answer: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout."
        },
        {
            id: "3",
            question: "What is lorem Ipsum?",
            answer: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
        },
        {
            id: "4",
            question: "Why do we use it?",
            answer: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout."
        },
        {
            id: "5",
            question: "What is lorem Ipsum?",
            answer: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
        },
        {
            id: "6",
            question: "Why do we use it?",
            answer: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout."
        },
    ]
    const navigation = useNavigation();
    const [show, setShow] = useState();

    const renderHeader = () => {
        return (
            <HeaderComp heading="FAQ" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    // const _renderFAQItems = ({ item }) => {
    //     return <FAQLists {...item} />
    // }

    return (
        <View style={styles.container}>
            <View style={{ marginTop: vs(5) }}>
                <FlatList
                    data={FaqData}
                    keyExtractor={(_, index) => index.toString()}
                    renderItem={({ item }) => {
                        return (
                            <View style={{ marginTop: vs(15), width: '95%', alignSelf: 'center' }}>
                                <Pressable onPress={() => setShow(item.id)}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>

                                        <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '500' }}>{item.question}</Text>
                                        {
                                            show === item.id ?
                                                (<Image source={images.collapse_icon}
                                                    style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />)
                                                :
                                                (<Image source={images.expand_icon}
                                                    style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />)
                                        }
                                    </View>
                                </Pressable>
                                {
                                    show === item.id ?
                                        (<Text style={{ fontSize: fs(16), color: colors.GreyText, marginTop: vs(10) }}>{item.answer}</Text>)
                                        :
                                        null
                                }
                                <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />
                            </View>
                        )
                    }}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default Faq;
