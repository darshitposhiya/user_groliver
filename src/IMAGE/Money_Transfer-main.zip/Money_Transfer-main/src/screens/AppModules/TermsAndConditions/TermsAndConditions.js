import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { vs, hs, fs, screenHeight, screenWidth } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';

const TermsAndConditions = () => {

    const LoremText = "Lorem Ipsum is simply summy text of the printing and typesetting industry."
    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp heading="Terms & conditions" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    return (
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ width: '95%', alignSelf: 'center', marginBottom: vs(20) }}>

                    <Image source={images.applogo1} style={{ height: screenHeight * 0.13, width: screenWidth * 0.40, resizeMode: 'contain', marginTop: vs(15) }} />

                    <Text style={{ marginTop: vs(10), fontSize: fs(18), color: colors.Black, fontWeight: '500' }}>About</Text>
                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}</Text>

                    <Text style={{ marginTop: vs(10), fontSize: fs(18), color: colors.Black, fontWeight: '500' }}>What is Lorem Ipsum?</Text>
                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}{LoremText}</Text>

                    <Text style={{ marginTop: vs(10), fontSize: fs(18), color: colors.Black, fontWeight: '500' }}>About</Text>
                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}</Text>

                    <Text style={{ marginTop: vs(10), fontSize: fs(18), color: colors.Black, fontWeight: '500' }}>What is Lorem Ipsum?</Text>
                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}{LoremText}</Text>

                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}{LoremText}</Text>
                    <Text style={{ marginTop: vs(5), fontSize: fs(16), color: colors.GreyText }}>{LoremText}{LoremText}</Text>
                </View>
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default TermsAndConditions;
