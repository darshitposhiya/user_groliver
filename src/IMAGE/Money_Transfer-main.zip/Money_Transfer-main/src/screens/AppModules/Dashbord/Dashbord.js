import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, Pressable } from 'react-native';
import { useNavigation } from "@react-navigation/native";
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import RecentTransactionList from '../../../components/ListViews/RecentTransactionList/RecentTransactionList';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { getStatusBarHeight } from '../../../utility/Globals';

const Dashboard = () => {

    const navigation = useNavigation();
    const statusBarHeight = getStatusBarHeight();

    const Transaction = [
        {
            name: "jenny Arthur",
            sent: "sent",
            date: "24 Mar 2023",
            amount: "20.50 EUR"
        },
        {
            name: "Michel",
            sent: "sent",
            date: "24 Mar 2023",
            amount: "200.50 GBP"
        },
        {
            name: "Brett",
            sent: "sent",
            date: "24 Mar 2023",
            amount: "200.50 GBP"
        },
    ]

    const renderHeader = () => {
        return (
            <View style={{ width: '100%', backgroundColor: colors.white, paddingTop: statusBarHeight }}>
                <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10), }}>
                    <Text style={{ fontSize: fs(26), color: colors.Black, fontWeight: '700' }}>Welcome</Text>
                </View>
            </View>

        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const renderRecentTransactions = ({ item }) => {
        return (<RecentTransactionList {...item} />)
    }
    return (
        <View style={styles.container}>

            <Pressable onPress={() => navigation.navigate('SendMoney')}>
                <View style={{
                    flexDirection: 'row',
                    width: '95%',
                    alignSelf: 'center',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    backgroundColor: colors.PrimaryBlue,
                    paddingVertical: vs(30),
                    paddingHorizontal: hs(10),
                    borderRadius: fs(10),
                    marginTop: vs(20)
                }}>
                    <View>
                        <Text style={{ fontSize: fs(18), color: colors.white }}>Send Money</Text>
                        <Text style={{ fontSize: fs(12), color: colors.white, marginTop: vs(3) }}>Lorem ipsum is simply dummy text </Text>
                        <Text style={{ fontSize: fs(12), color: colors.white }}>of the printing</Text>
                    </View>

                    <Image source={images.send_right_arrow}
                        style={{ height: vs(40), width: hs(40), resizeMode: 'contain' }} />

                </View>
            </Pressable>

            <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(15), }}>
                <View style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{ fontWeight: '700', color: colors.Black, fontSize: fs(18) }}>
                        Recent transactions
                    </Text>
                    <Pressable>
                        <Text style={{ color: colors.Lightblue, fontSize: fs(16), textDecorationLine: 'underline' }}>see all</Text>
                    </Pressable>
                </View>

                <FlatList
                    data={Transaction}
                    renderItem={renderRecentTransactions}
                    keyExtractor={(_, index) => index.toString()} />
            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: '100%',
        alignSelf: 'center',
        backgroundColor: colors.white
    },
});

export default Dashboard;
