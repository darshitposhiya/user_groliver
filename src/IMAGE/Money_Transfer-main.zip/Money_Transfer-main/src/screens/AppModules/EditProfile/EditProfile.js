import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { useNavigation } from '@react-navigation/native';
import TextInputWithLabel from '../../../components/TextInputWithLabel';
import InputComp from '../../../components/InputComp';
import BtnComp from '../../../components/BtnComp';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scrollview';
import HeaderComp from '../../../components/HeaderComp';
import { Formik } from 'formik';
import { editProfileValidate } from '../../../utility/Validations';

const EditProfile = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp heading="Edit profile" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    const editProfileHandler = (data) =>{

        console.log("EditProfile",data)
        navigation.navigate('Account')
    }

    return (
        <View style={styles.container}>
            <Formik
                initialValues={editProfileValidate.initialState}
                validationSchema={editProfileValidate.schema}
                onSubmit={(values) => editProfileHandler(values)}
            // enableReinitialize={true}
            // innerRef={formRef}
            >
                {({ values, setFieldTouched, handleChange, handleSubmit, errors, touched }) => (
                    <>
                        <KeyboardAwareScrollView>
                            <View style={{ width: '95%', alignSelf: 'center' }}>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(20) }}>
                                    <View style={{ width: '49%' }}>
                                        <TextInputWithLabel
                                            placeholder={'First name'}
                                            value={values.first_name}
                                            onChangeText={handleChange("first_name")}
                                            onBlur={() => setFieldTouched('first_name')}
                                            touched={touched.first_name}
                                            errors={errors.first_name}
                                            inputStyle={{ borderColor: touched.first_name && errors.first_name ? 'red' : colors.InputGray_Border, }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <TextInputWithLabel
                                            placeholder={'Last name'}
                                            value={values.last_name}
                                            onChangeText={handleChange("last_name")}
                                            onBlur={() => setFieldTouched('last_name')}
                                            touched={touched.last_name}
                                            errors={errors.last_name}
                                            inputStyle={{ borderColor: touched.last_name && errors.last_name ? 'red' : colors.InputGray_Border }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder={'Email'}
                                    value={values.email}
                                    onChangeText={handleChange("email")}
                                    onBlur={() => setFieldTouched('email')}
                                    touched={touched.email}
                                    keyboardType='email-address'
                                    autoCapitalize='none'
                                    inputStyle={{ marginTop: vs(15), borderColor: touched.email && errors.email ? 'red' : colors.InputGray_Border }} />

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                                    <View style={{ width: '25%' }}>
                                        <InputComp
                                            placeholder={'+27'}
                                            value={values.phone_code}
                                            onChangeText={handleChange("phone_code")}
                                            onBlur={() => setFieldTouched('phone_code')}
                                            touched={touched.phone_code}
                                           // editable={false}
                                            pointerEvents="box-only"
                                            input_view={{ borderColor: touched.phone_code && errors.phone_code ? 'red' : colors.InputGray_Border }} />
                                    </View>

                                    <View style={{ width: '73%' }}>
                                        <TextInputWithLabel
                                            placeholder={'Phone number'}
                                            value={values.phone}
                                            onChangeText={handleChange("phone")}
                                            onBlur={() => setFieldTouched('phone')}
                                            touched={touched.phone}
                                            inputStyle={{ borderColor: touched.phone && errors.phone ? 'red' : colors.InputGray_Border, }} />
                                    </View>
                                </View>

                                <Text style={{ marginTop: vs(15), fontSize: fs(18), fontWeight: '500', color: colors.Black }}>Address</Text>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'Country'}
                                            value={values.country}
                                            onChangeText={handleChange("country")}
                                            onBlur={() => setFieldTouched('country')}
                                            touched={touched.country}
                                           // editable={false}
                                            input_view={{ borderColor: touched.country && errors.country ? 'red' : colors.InputGray_Border }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'State'}
                                            value={values.state}
                                            onChangeText={handleChange("state")}
                                            onBlur={() => setFieldTouched('state')}
                                            touched={touched.state}
                                            input_view={{ borderColor: touched.state && errors.state ? 'red' : colors.InputGray_Border }} />
                                    </View>
                                </View>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'City'}
                                            value={values.city}
                                            onChangeText={handleChange("city")}
                                            onBlur={() => setFieldTouched('city')}
                                            touched={touched.city}
                                            input_view={{ borderColor: touched.city && errors.city ? 'red' : colors.InputGray_Border }} />
                                    </View>

                                    <View style={{ width: '49%' }}>
                                        <InputComp
                                            placeholder={'Postal code'}
                                            value={values.postal_code}
                                            onChangeText={handleChange("postal_code")}
                                            onBlur={() => setFieldTouched('postal_code')}
                                            touched={touched.postal_code}
                                            input_view={{ borderColor: touched.postal_code && errors.postal_code ? 'red' : colors.InputGray_Border }} />
                                    </View>
                                </View>

                                <TextInputWithLabel
                                    placeholder={'Address'}
                                    value={values.address}
                                    onChangeText={handleChange("address")}
                                    onBlur={() => setFieldTouched('address')}
                                    touched={touched.address}
                                    multiline={true}
                                    inputStyle={{
                                        height: vs(100), marginTop: vs(15), justifyContent: 'flex-start',
                                        borderColor: touched.address && errors.address ? 'red' : colors.InputGray_Border
                                    }} />

                                <BtnComp onPress={handleSubmit} title="Save" btnStyle={{ marginBottom: vs(10), marginTop: vs(60) }} />
                            </View>
                        </KeyboardAwareScrollView>
                    </>
                )}
            </Formik>
        </View >
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default EditProfile;
