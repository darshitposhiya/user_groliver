import React, { useLayoutEffect } from 'react';
import { View, Text, StyleSheet, } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';
import { useNavigation } from '@react-navigation/native';
import HeaderComp from '../../../components/HeaderComp';

const TransactionReport = () => {

    const navigation = useNavigation();

    const renderHeader = () => {
        return (
            <HeaderComp heading="Transaction report" onPress={() => navigation.goBack()} />
        )
    }

    useLayoutEffect(() => {
        navigation.setOptions({
            header: () => {
                return renderHeader();
            }
        });
    }, []);

    return (
        <View style={styles.container}>
            <View style={{ width: '95%', alignSelf: 'center', }}>
                <View style={{ marginTop: vs(5) }}>

                    <Row_Box LeftTitle="Name" LeftText="Jenny Arthue" RightTitle="Date" RightText="23 Mar 2023" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box LeftTitle="From" LeftText="Canada" RightTitle="To" RightText="Cameroon" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box LeftTitle="Sent" LeftText="1000 EUR" RightTitle="Receives" RightText="638,234 XAF" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box LeftTitle="Pickup location" LeftText="Banque Atantique" />
                    <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(15) }} />

                    <Row_Box LeftTitle="Transaction code" LeftText="6279-21764b49-6" />

                </View>
            </View>
        </View>
    );
};

const Row_Box = (
    {
        LeftTitle,
        LeftText,
        RightTitle,
        RightText
    }
) => {
    return (
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: vs(15) }}>
            <View style={{ width: '50%' }}>
                <Text style={{ fontSize: fs(14), color: colors.Black }}>{LeftTitle}</Text>
                <Text style={{ fontSize: fs(16), color: colors.Black, fontWeight: '600', marginTop: vs(3) }}>{LeftText}</Text>
            </View>

            <View style={{ width: '50%' }}>
                <Text style={{ fontSize: fs(14), color: colors.Black }}>{RightTitle}</Text>
                <Text style={{ fontSize: fs(16), color: colors.Black, fontWeight: '600', marginTop: vs(3) }}>{RightText}</Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default TransactionReport;
