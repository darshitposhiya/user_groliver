import React, { Component } from 'react';
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Tabs from './Tabs';
import SendMoney from '../screens/AppModules/SendMoney/SendMoney';
import SendToCountry from '../screens/AppModules/SendToCountry/SendToCountry';
import ChoosePickupLocation from '../screens/AppModules/ChoosePickupLocation/ChoosePickupLocation';
import RecipientDetails from '../screens/AppModules/Recipient_Details/RecipientDetails';
import Dashboard from '../screens/AppModules/Dashbord/Dashbord';
import TransactionSummary from '../screens/AppModules/TransactionSummary/TransactionSummary';
import ReceiptCreated from '../screens/AppModules/ReceiptCreated/ReceiptCreated';
import TransactionReport from '../screens/AppModules/TransactionReport/TransactionReport';
import EditProfile from '../screens/AppModules/EditProfile/EditProfile';
import AccountSetting from '../screens/AppModules/AccountSetting/AccountSetting';
import Faq from '../screens/AppModules/Faq/Faq';
import ChangePassword from '../screens/AppModules/ChangePassword/ChangePassword';
import TermsAndConditions from '../screens/AppModules/TermsAndConditions/TermsAndConditions';
import CurrencyCode from '../screens/AppModules/CurrencyCode/CurrencyCode';


const RootStack = createNativeStackNavigator();

const AppStack = ({}) => {

    return (
        <RootStack.Navigator>
            <RootStack.Screen
                name='Tabs'
                component={Tabs}
                options={{
                    headerShown: false,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
              <RootStack.Screen
                name='Dashbord'
                component={Dashboard}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
            <RootStack.Screen
                name='SendMoney'
                component={SendMoney}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='SendToCountry'
                component={SendToCountry}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
              <RootStack.Screen
                name='CurrencyCode'
                component={CurrencyCode}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='ChoosePickupLocation'
                component={ChoosePickupLocation}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='RecipientDetails'
                component={RecipientDetails}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='TransactionSummary'
                component={TransactionSummary}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='ReceiptCreated'
                component={ReceiptCreated}
                options={{
                    headerShown: false,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
            <RootStack.Screen
                name='TransactionReport'
                component={TransactionReport}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='EditProfile'
                component={EditProfile}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='AccountSetting'
                component={AccountSetting}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='Faq'
                component={Faq}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='ChangePassword'
                component={ChangePassword}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
             <RootStack.Screen
                name='TermsAndConditions'
                component={TermsAndConditions}
                options={{
                    headerShown: true,
                    headerShadowVisible: false,
                    headerTitle: '',
                }}
            />
           
        </RootStack.Navigator>
    );
};

export default AppStack;
