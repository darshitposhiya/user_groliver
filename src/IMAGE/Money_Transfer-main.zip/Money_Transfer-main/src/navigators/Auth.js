import React, { Component } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AppIntro from '../screens/AuthModules/AppIntroduction/AppIntro';
import Splash from '../screens/AuthModules/Splash/Splash';
import SignIn from '../screens/AuthModules/SignIn/SignIn';
import ForgotPassword from '../screens/AuthModules/ForgotPassword/ForgotPassword';
import { fonts } from '../assets/fonts/Fonts';
import Verification from '../screens/AuthModules/Verification/Verification';
import ResetPassword from '../screens/AuthModules/ResetPassword/ResetPassword';
import SignUp from '../screens/AuthModules/SignUp/SignUp';
import ChooseLocation from '../screens/AuthModules/ChooseLocation/ChooseLocation';
import Tabs from './Tabs';
import Country from '../screens/AuthModules/Country/Country';

const Stack = createNativeStackNavigator();

const AuthStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        animation: 'slide_from_right',
        headerBackTitleVisible: false,
        headerShown: false,
        headerShadowVisible: false,
        headerTitleStyle: {
          fontFamily: fonts.regular
        },
        contentStyle: {
          backgroundColor: 'white'
        },
      }}>

      <Stack.Screen
        name='Splash'
        component={Splash}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name='AppIntro'
        component={AppIntro}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name='SignIn'
        component={SignIn}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name='ForgotPassword'
        component={ForgotPassword}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

      <Stack.Screen
        name='Verification'
        component={Verification}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

      <Stack.Screen
        name='ResetPassword'
        component={ResetPassword}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

      <Stack.Screen
        name='SignUp'
        component={SignUp}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

      <Stack.Screen
        name='Country'
        component={Country}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

      <Stack.Screen
        name='ChooseLocation'
        component={ChooseLocation}
        options={{
          headerShown: true,
          headerShadowVisible: false,
          headerTitle: '',
        }}
      />

    </Stack.Navigator>
  );
};

export default AuthStack;
