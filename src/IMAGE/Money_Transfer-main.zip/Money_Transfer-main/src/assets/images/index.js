export const images = {
    applogo:require('../images/1-splash/splash.png'),
    intro1:require('../images/2-3-4-Intro/1.png'),
    intro2:require('../images/2-3-4-Intro/2.png'),
    intro3:require('../images/2-3-4-Intro/3.png'),
    blue_dot:require('../images/2-3-4-Intro/blue_dot.png'),
    gray_dot:require('../images/2-3-4-Intro/gray_dot.png'),
    right_arrow:require('../images/2-3-4-Intro/right_arrow.png'),
    applogo_login:require('../images/5-login/logo.png'),
    googleIcon: require('../images/5-login/Google.png'),
    hide_psw:require('../images/5-login/Hide.png'),
    visible_psw:require('../images/5-login/Visible.png'),
    back_icon:require('../images/6-7-8-9-forgot-pw/back.png'),
    success:require('../images/6-7-8-9-forgot-pw/success.png'),
    flag:require('../images/10-signup/flag.png'),
    location_img:require('../images/11-location/location.png'),

    footer: {
        home_active: require('../images/12-home/footer/Home_active.png'),
        home_deactive: require('../images/12-home/footer/Home.png'),
        history_active: require('../images/12-home/footer/History_acive.png'),
        history_deactive:require('../images/12-home/footer/History.png'),
        account_active: require('../images/12-home/footer/Acccount_active.png'),
        account_deactive: require('../images/12-home/footer/Acccount.png'),
        alert_active: require('../images/12-home/footer/Alerts_active.png'),
        alert_deactive: require('../images/12-home/footer/Alerts.png'),
        send_tab: require('../images/12-home/footer/send.png'),
    },

    send_right_arrow:require('../images/12-home/send_right_arrow.png'),
    send_money:require('../images/12-home/send_money.png'),
    search:require('../images/13-select-country/search.png'),
    usa:require('../images/13-select-country/usa.png'),
    belgium:require('../images/13-select-country/Belgium.png'),
    applogo1:require('../images/14-15-amount/logo.png'),
    close:require('../images/14-15-amount/close.png'),
    radio_selected:require('../images/16-pickup/radio_selected.png'),
    radio_unselected:require('../images/16-pickup/radio.png'),
    right:require('../images/18-19-transaction-summary/right.png'),
    recipent:require('../images/20-21-22-history/recipent.png'),
    logo_alert:require('../images/23-alert/logo-alert.png'),

    //account
    bg:require('../images/24-account/bg.png'),
    ac_setting:require('../images/24-account/ac_setting.png'),
    change_psw:require('../images/24-account/change-pw.png'),
    faq:require('../images/24-account/faq.png'),
    logout:require('../images/24-account/logout.png'),
    terms:require('../images/24-account/terms.png'),
    collapse_icon:require('../images/27-faq/collapse.png'),
    expand_icon:require('../images/27-faq/expand.png')


}