export const fonts = {
    regular: 'SFProText-Regular',
    semiBold: 'SFProText-Semibold',
    bold: 'SFProText-Bold'
}