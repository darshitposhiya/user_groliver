export const colors = {
    PrimaryBlue: "#2764A2",
    GreyText:'#777777',
    Lightblue: "#0B96D9",
    InputGray_Border: "#CCCCCC",
    InputGray_text: "#BFBFBF",
    Bluetab_footer: "#0B96D9",
    Graytab_footer: "#969599",
    Black:'#000',
    white:'#FFFFFF'
}