import { createSlice } from "@reduxjs/toolkit";

const dashboardSlice = createSlice({
    name: 'dashboardSlice',
    initialState: {
        country_currency: '',
    },
    reducers: {
        setCountryCurrency: (state, { payload }) => {
            state.country_currency = payload;
        },
    },
})

export const { setCountryCurrency } = dashboardSlice.actions;