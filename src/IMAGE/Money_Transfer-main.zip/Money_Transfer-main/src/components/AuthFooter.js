import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../assets/colors/Colors';
import { vs } from '../utility/ResponsiveStyle';

const AuthFooter = ({
    children
}) => {
    return (
       <View style={{
        position: 'absolute',
        bottom: -10,
        width: '100%',
        justifyContent: 'center',
        
       }}
       >
        <View style={{
             position: 'absolute',
             alignSelf: 'center',
             flexDirection: 'row',
             justifyContent: 'center',
             bottom: 20,
        }}>
            {children}
        </View>
       </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:colors.white
    },
});

export default AuthFooter;
