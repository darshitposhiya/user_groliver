import React, { Component } from 'react';
import { View, Text, StyleSheet, Pressable, Image } from 'react-native';
import { images } from '../assets/images';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../assets/colors/Colors';
import { hs, vs, fs } from '../utility/ResponsiveStyle';
import { getStatusBarHeight } from '../utility/Globals';
import { fonts } from '../assets/fonts/Fonts';

const HeaderComp = (
    {
        heading,
        onPress
    }
) => {

    const navigation = useNavigation();
    const statusBarHeight = getStatusBarHeight();

    return (
        <View style={{ width: '100%', backgroundColor: colors.white, paddingTop: statusBarHeight }}>
            <View style={{ width: '95%', alignSelf: 'center', marginTop: vs(10), flexDirection: 'row', alignItems: 'center' }}>
                <Pressable onPress={onPress}>
                    <Image source={images.back_icon}
                        style={{ height: vs(45), width: hs(45), resizeMode: 'contain' }}
                    />
                </Pressable>
                <Text style={{ fontSize: fs(22), color: colors.Black, fontWeight: '700', fontFamily: fonts.bold, marginHorizontal: hs(10) }}>{heading}</Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
   
});

export default HeaderComp;
