import React, { Component } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { images } from '../../../assets/images';
import { hs , vs , fs } from '../../../utility/ResponsiveStyle';

const RecentTransactionList = ({
    name, sent, amount, date
}) => {
    return (
        <View style={styles.container}>
            <View style={{ marginTop: vs(15) }}>
                <View style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Image source={images.send_money}
                            style={{ height: vs(40), width: hs(40), resizeMode: 'contain' }} />

                        <View style={{ marginHorizontal: hs(10) }}>
                            <Text style={{fontSize:fs(16),fontWeight:'500',color:colors.Black}}>{name}</Text>
                            <Text style={{fontSize:fs(14),color:colors.GreyText}}>{sent} {date}</Text>
                        </View>
                    </View>

                    <Text style={{fontSize:fs(16),fontWeight:'600',color:colors.PrimaryBlue}}>{amount}</Text>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default RecentTransactionList;
