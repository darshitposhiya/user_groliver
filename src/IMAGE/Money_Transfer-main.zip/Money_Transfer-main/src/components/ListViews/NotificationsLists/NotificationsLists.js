import React, { Component } from 'react';
import { View, Text, Image } from 'react-native';
import { images } from '../../../assets/images';
import { hs, vs,fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';

const NotificationsLists = (
    {
        title,
        detail,
        time
    }
) => {
    return (
       <View style={{flexDirection:'row',marginTop:vs(15),justifyContent:'space-between'}}>
        <Image source={images.logo_alert} 
        style={{height:vs(50),width:hs(50),resizeMode:'contain'}} />

        <View style={{marginLeft:hs(10),marginRight:hs(5)}}>
            <Text style={{fontSize:fs(18),color:colors.Black,fontWeight:'700'}}>{title}</Text>
            <Text style={{fontSize:fs(14),color:colors.Black,marginTop:vs(2)}}>{detail}</Text>
            <Text style={{fontSize:fs(12),color:colors.GreyText,marginTop:vs(2)}}>{time}</Text>
        </View>
       </View>
    );
};


export default NotificationsLists;
