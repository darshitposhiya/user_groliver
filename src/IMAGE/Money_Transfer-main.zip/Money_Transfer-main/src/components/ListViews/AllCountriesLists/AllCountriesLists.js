import { useNavigation } from '@react-navigation/native';
import React, { Component } from 'react';
import { View, Text, Pressable, } from 'react-native';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';

const AllCountriesLists = ({
    name,
    country,
    currency_code,
    flag
}) => {

    const navigation = useNavigation();

    return (
        <Pressable onPress={() => navigation.navigate('SendToCountry', {
            countryName: country,
            currencyCode: currency_code
        })}>
            <View style={{ marginTop: vs(15) }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text style={{ fontSize: fs(18), color: colors.Black }}>{flag}</Text>
                        <Text style={{ fontSize: fs(18), color: colors.Black, marginLeft: hs(10) }} >{country}</Text>
                    </View>

                    <Text style={{ fontSize: fs(16), color: colors.Black, marginHorizontal: hs(10) }}>{currency_code}</Text>
                </View>
            </View>
        </Pressable>
    );
};


export default AllCountriesLists;
