import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, Pressable } from 'react-native';
import { colors } from '../../../assets/colors/Colors';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { images } from '../../../assets/images';

const PickUpItemsLists = ({
    select,
    //selectHandler,
    name,
    time1,
    time2,
}) => {
    return (
        <View style={styles.container}>
            <Pressable>
                <View style={{ paddingVertical: vs(20), marginTop: vs(15), borderWidth: fs(1), borderColor: colors.InputGray_Border, borderRadius: 10 }}>

                    <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: hs(15) }}>
                        {select ?
                            (<Image source={images.radio_selected}
                                style={{ height: vs(20), width: hs(20), resizeMode: 'contain' }} />)
                            :
                            (<Image source={images.radio_unselected}
                                style={{ height: vs(20), width: hs(20), resizeMode: 'contain' }} />)
                        }

                        <View style={{ marginHorizontal: hs(20) }}>
                            <Text style={{ fontSize: fs(18), color: colors.Black, fontWeight: '700' }}>{name}</Text>
                            <Text style={{ fontSize: fs(14), color: colors.Black, marginTop: vs(3) }}>{time1}</Text>
                            <Text style={{ fontSize: fs(14), color: colors.Black }}>{time2}</Text>
                        </View>
                    </View>
                </View>

            </Pressable>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white
    },
});

export default PickUpItemsLists;
