import React, { useState } from 'react';
import { View, Text, Image, Pressable, } from 'react-native';
import { images } from '../../../assets/images';
import { hs, vs, fs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';

const FAQLists = (
    {
        id,
        question,
        answer
    }
) => {

    const [show, setShow] = useState();
    console.log(id)
    return (
        <View style={{marginTop:vs(10),width:'95%',alignSelf:'center'}}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>

                <Text style={{fontSize:fs(18),color:colors.Black,fontWeight:'700'}}>{question}</Text>
                <Pressable onPress={()=>setShow(id)}>
                    {
                        show === id ? 
                        ( <Image source={images.collapse_icon}
                            style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />)
                         :
                          ( <Image source={images.expand_icon}
                            style={{ height: vs(10), width: hs(10), resizeMode: 'contain' }} />)
                    }  
                </Pressable>
                
            </View>
            {
                show === id ? 
                ( <Text style={{fontSize:fs(16),color:colors.GreyText,marginTop:vs(5)}}>{answer}</Text>) 
                :
                 null
            }  
            <View style={{ borderWidth: 1, borderColor: '#000000', opacity: 0.1, marginTop: vs(10) }} />
        </View>
    );
};

export default FAQLists;
