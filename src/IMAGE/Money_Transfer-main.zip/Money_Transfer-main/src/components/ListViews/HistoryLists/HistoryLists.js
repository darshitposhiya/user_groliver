import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, Pressable } from 'react-native';
import { vs, hs, fs } from '../../../utility/ResponsiveStyle';
import { images } from '../../../assets/images';
import { colors } from '../../../assets/colors/Colors';

const HistoryLists = (
    {
        name,
        date,
        amount
    }) => {
    return (
        <Pressable>
            <View style={{ marginTop: vs(15), flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: vs(20), paddingHorizontal: hs(10), borderWidth: 1, borderRadius: 5, borderColor: colors.InputGray_Border }}>

                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Image source={images.recipent}
                        style={{ height: vs(40), width: hs(40), resizeMode: 'contain' }} />

                    <View style={{ marginHorizontal: hs(10) }}>
                        <Text style={{ fontSize: fs(16), fontWeight: '600', color: colors.Black }}>{name}</Text>
                        <Text style={{ fontSize: fs(14), color: colors.GreyText }}>{date}</Text>
                    </View>
                </View>

                <Text style={{ fontSize: fs(16), fontWeight: '600', color: colors.PrimaryBlue }}>{amount}</Text>
            </View>
        </Pressable>

    );
};

const styles = StyleSheet.create({

});

export default HistoryLists;
