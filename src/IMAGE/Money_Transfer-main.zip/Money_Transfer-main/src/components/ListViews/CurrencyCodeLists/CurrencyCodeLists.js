import React, { Component } from 'react';
import { View, Text, Pressable, } from 'react-native';
import { fs, hs, vs } from '../../../utility/ResponsiveStyle';
import { colors } from '../../../assets/colors/Colors';

const CurrecyCodeLists = (
    {
        goToCountry, country, currency_code, flag
    }) => {
    return (
        <Pressable onPress={goToCountry}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',paddingHorizontal:hs(15),height:40,}}>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    <Text style={{fontSize:fs(18)}}>{flag}</Text>
                    <Text style={{fontSize:fs(18),color:colors.Black,marginHorizontal:hs(10)}}>{country}</Text>
                </View>

                <Text style={{fontSize:fs(16),color:colors.Black}}>{currency_code}</Text>
            </View>
        </Pressable>
    );
};

export default CurrecyCodeLists;
