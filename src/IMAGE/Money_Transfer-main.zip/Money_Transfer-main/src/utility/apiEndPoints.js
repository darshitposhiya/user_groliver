export const BaseUrl = 'https://chessmafia.com/php/ankit/n-joo-transfer/App/api/';
export const imageBaseUrl = 'https://chessmafia.com/php/ankit/n-joo-transfer/App/';

export const endPoints = {
    register: 'register',
    update_locations: 'update-locations',
    login: 'login',
    google_login: 'login-with-google',
    logout: 'logout',
    forgot_password: 'forgot-password',
    otp_verify: 'otp-verify',
    reset_password: 'reset-password',
    get_countries: 'get-countries',
    get_currency_value: 'get-currency-value',
    send_money_request: 'send-money-request',
    add_receipt_detail: 'add-recipt-detail',
    get_recent_transaction: 'get-recent-transaction',
    update_profile: 'update-profile',
    change_password: 'change-password',
    faq_content: 'get-faq-tabs-content',
    terms_content: 'get-terms-content',
    vendor_transaction: 'get-vendor-transaction',
    upload_receipt_sign: 'upload-recipt-sinature',
    history_transaction: 'get-recent-transaction',
    getPickUpLocation: 'get-pickup-location',
    setPickUpLocation: 'set-pickup-location',
    getUserDetails: 'get-user-details',
    transactionSummary: 'get-taransaction-summary',
    complete_money_request: 'complete-money-request',
    transactionReportsLists: 'get-transaction-report',
    deleteAccount: 'delete-my-account',
    notificationListing:'get-notification-list',
    update_notification: 'update-notification-status'
}